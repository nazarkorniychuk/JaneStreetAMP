#Dictionaries use a key-value lookup pairing
prime_lookup = {'a': 2, 'b': 3, 'c': 5, 'd': 7, 'e': 11, 'f': 13,
    'g': 17, 'h': 19, 'i': 23, 'j': 29, 'k': 31, 'l': 37, 'm': 41, 'n': 43, 
    'o': 47, 'p': 53, 'q': 59, 'r': 61, 's': 67, 't': 71, 'u': 73, 'v': 79, 
    'w': 83, 'x': 89, 'y': 97, 'z': 101 }

print(prime_lookup['c']) #5
print(list(prime_lookup.keys())) 
#['a', 'b', 'c', 'd', 'e', 'f', 'g', 'h', 'i', 'j', 'k', 'l', 'm', 'n', 'o', 'p', 'q', 'r', 's', 't', 'u', 'v', 'w', 'x', 'y', 'z']

print(list(prime_lookup.values()))  
#[2, 3, 5, 7, 11, 13, 17, 19, 23, 29, 31, 37, 41, 43, 47, 53, 59, 61, 67, 71, 73, 79, 83, 89, 97, 101]

#Dictionary keys are unordered, but you can loop over them with a for…in loop
for k in prime_lookup:
   print(k, prime_lookup[k])